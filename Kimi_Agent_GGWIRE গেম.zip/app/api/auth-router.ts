import * as cookie from "cookie";
import { sql } from "drizzle-orm";
import { Session } from "@contracts/constants";
import { getSessionCookieOptions } from "./lib/cookies";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { users } from "@db/schema";

export const authRouter = createRouter({
  me: authedQuery.query((opts) => opts.ctx.user),

  // Bootstrap: the first signed-in user becomes admin when no admin exists yet.
  claimAdmin: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();
    const admins = await db.select({ id: users.id }).from(users).where(sql`${users.role} = 'admin'`).limit(1);
    if (admins.length > 0) return { admin: ctx.user.role === "admin" };
    await db.update(users).set({ role: "admin" }).where(sql`${users.id} = ${ctx.user.id}`);
    return { admin: true };
  }),
  logout: authedQuery.mutation(async ({ ctx }) => {
    const opts = getSessionCookieOptions(ctx.req.headers);
    ctx.resHeaders.append(
      "set-cookie",
      cookie.serialize(Session.cookieName, "", {
        httpOnly: opts.httpOnly,
        path: opts.path,
        sameSite: opts.sameSite?.toLowerCase() as "lax" | "none",
        secure: opts.secure,
        maxAge: 0,
      }),
    );
    return { success: true };
  }),
});
