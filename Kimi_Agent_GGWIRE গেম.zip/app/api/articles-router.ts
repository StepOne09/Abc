import { z } from "zod";
import { desc, eq, sql, asc, like, or, and, ne } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { articles, authors, categories, articleViews, comments, users } from "@db/schema";

const db = () => getDb();

const articleCard = {
  id: articles.id,
  slug: articles.slug,
  title: articles.title,
  excerpt: articles.excerpt,
  featuredImage: articles.featuredImage,
  views: articles.views,
  publishedAt: articles.publishedAt,
  category: { id: categories.id, name: categories.name, slug: categories.slug, color: categories.color },
  author: { id: authors.id, name: authors.name, slug: authors.slug, avatar: authors.avatar, role: authors.role, bio: authors.bio },
};

export const articlesRouter = createRouter({
  home: publicQuery.query(async () => {
    const d = db();
    const published = eq(articles.status, "published");
    const featuredRows = await d.select(articleCard).from(articles).innerJoin(categories, eq(articles.categoryId, categories.id)).innerJoin(authors, eq(articles.authorId, authors.id)).where(published).orderBy(desc(articles.publishedAt)).limit(1);
    const featuredId = featuredRows[0]?.id ?? 0;
    const [secondary, trending, latest, editorsPicks, categoriesList] = await Promise.all([
      d.select(articleCard).from(articles).innerJoin(categories, eq(articles.categoryId, categories.id)).innerJoin(authors, eq(articles.authorId, authors.id)).where(published).orderBy(desc(articles.publishedAt)).limit(4).offset(1),
      d.select(articleCard).from(articles).innerJoin(categories, eq(articles.categoryId, categories.id)).innerJoin(authors, eq(articles.authorId, authors.id)).where(published)
        .orderBy(sql`(${articles.views} / POW(GREATEST(TIMESTAMPDIFF(HOUR, ${articles.publishedAt}, NOW()), 1), 1.4)) DESC`)
        .limit(6),
      d.select(articleCard).from(articles).innerJoin(categories, eq(articles.categoryId, categories.id)).innerJoin(authors, eq(articles.authorId, authors.id)).where(published).orderBy(desc(articles.publishedAt)).limit(9),
      d.select(articleCard).from(articles).innerJoin(categories, eq(articles.categoryId, categories.id)).innerJoin(authors, eq(articles.authorId, authors.id)).where(and(published, ne(articles.id, featuredId))).orderBy(sql`RAND()`).limit(4),
      d.select().from(categories).orderBy(asc(categories.id)),
    ]);
    return { featured: featuredRows[0] ?? null, secondary, trending, latest, editorsPicks, categories: categoriesList };
  }),

  byCategory: publicQuery
    .input(z.object({ slug: z.string(), sort: z.enum(["latest", "popular"]).default("latest"), offset: z.number().int().min(0).default(0), limit: z.number().int().min(1).max(30).default(9) }))
    .query(async ({ input }) => {
      const d = db();
      const cat = await d.select().from(categories).where(eq(categories.slug, input.slug)).limit(1);
      if (!cat[0]) return { category: null, items: [], total: 0 };
      const where = and(eq(articles.categoryId, cat[0].id), eq(articles.status, "published"));
      const order = input.sort === "popular"
        ? sql`(${articles.views} / POW(GREATEST(TIMESTAMPDIFF(HOUR, ${articles.publishedAt}, NOW()), 1), 1.4)) DESC`
        : desc(articles.publishedAt);
      const [items, count] = await Promise.all([
        d.select(articleCard).from(articles).innerJoin(categories, eq(articles.categoryId, categories.id)).innerJoin(authors, eq(articles.authorId, authors.id)).where(where).orderBy(order).limit(input.limit).offset(input.offset),
        d.select({ n: sql<number>`COUNT(*)` }).from(articles).where(where),
      ]);
      return { category: cat[0], items, total: Number(count[0]?.n ?? 0) };
    }),

  bySlug: publicQuery.input(z.object({ slug: z.string() })).query(async ({ input }) => {
    const d = db();
    const rows = await d.select({ ...articleCard, body: articles.body, status: articles.status })
      .from(articles).innerJoin(categories, eq(articles.categoryId, categories.id)).innerJoin(authors, eq(articles.authorId, authors.id))
      .where(and(eq(articles.slug, input.slug), eq(articles.status, "published"))).limit(1);
    if (!rows[0]) return { article: null, related: [] };
    const related = await d.select(articleCard).from(articles).innerJoin(categories, eq(articles.categoryId, categories.id)).innerJoin(authors, eq(articles.authorId, authors.id))
      .where(and(eq(articles.categoryId, rows[0].category.id), eq(articles.status, "published"), ne(articles.id, rows[0].id)))
      .orderBy(desc(articles.publishedAt)).limit(3);
    return { article: rows[0], related };
  }),

  recordView: publicQuery
    .input(z.object({ slug: z.string(), viewerKey: z.string().min(8).max(128) }))
    .mutation(async ({ input }) => {
      const d = db();
      const art = await d.select({ id: articles.id }).from(articles).where(eq(articles.slug, input.slug)).limit(1);
      if (!art[0]) return { ok: false };
      const inserted = await d.insert(articleViews).values({ articleId: art[0].id, viewerKey: input.viewerKey }).onDuplicateKeyUpdate({ set: {} }).catch(() => null);
      if (inserted) {
        await d.update(articles).set({ views: sql`${articles.views} + 1` }).where(eq(articles.id, art[0].id));
      }
      return { ok: true };
    }),

  search: publicQuery
    .input(z.object({ q: z.string().min(1).max(120) }))
    .query(async ({ input }) => {
      const q = `%${input.q}%`;
      return db().select(articleCard).from(articles).innerJoin(categories, eq(articles.categoryId, categories.id)).innerJoin(authors, eq(articles.authorId, authors.id))
        .where(and(eq(articles.status, "published"), or(like(articles.title, q), like(articles.excerpt, q))))
        .orderBy(desc(articles.publishedAt)).limit(12);
    }),

  comments: publicQuery.input(z.object({ articleSlug: z.string() })).query(async ({ input }) => {
    const d = db();
    const art = await d.select({ id: articles.id }).from(articles).where(eq(articles.slug, input.articleSlug)).limit(1);
    if (!art[0]) return [];
    return d.select({
      id: comments.id, body: comments.body, parentId: comments.parentId, createdAt: comments.createdAt,
      user: { id: users.id, name: users.name, avatar: users.avatar },
    }).from(comments).innerJoin(users, eq(comments.userId, users.id)).where(eq(comments.articleId, art[0].id)).orderBy(asc(comments.createdAt)).limit(200);
  }),
});
