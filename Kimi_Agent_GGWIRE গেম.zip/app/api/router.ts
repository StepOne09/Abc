import { authRouter } from "./auth-router";
import { articlesRouter } from "./articles-router";
import { siteRouter } from "./site-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  articles: articlesRouter,
  site: siteRouter,
});

export type AppRouter = typeof appRouter;
