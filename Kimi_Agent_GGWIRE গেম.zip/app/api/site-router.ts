import { z } from "zod";
import { eq, desc, sql } from "drizzle-orm";
import { createRouter, publicQuery, authedQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { articles, bookmarks, comments, matches, newsletterSubscribers, users } from "@db/schema";

const db = () => getDb();

export const siteRouter = createRouter({
  matches: publicQuery.query(async () => {
    const all = await db().select().from(matches).orderBy(desc(matches.startTime)).limit(30);
    return all;
  }),

  subscribe: publicQuery
    .input(z.object({ email: z.string().email().max(320) }))
    .mutation(async ({ input }) => {
      const d = db();
      const existing = await d.select({ id: newsletterSubscribers.id }).from(newsletterSubscribers).where(eq(newsletterSubscribers.email, input.email)).limit(1);
      if (!existing[0]) await d.insert(newsletterSubscribers).values({ email: input.email });
      return { success: true };
    }),

  addComment: authedQuery
    .input(z.object({ articleSlug: z.string(), body: z.string().min(2).max(2000), parentId: z.number().int().optional() }))
    .mutation(async ({ ctx, input }) => {
      const d = db();
      const art = await d.select({ id: articles.id }).from(articles).where(eq(articles.slug, input.articleSlug)).limit(1);
      if (!art[0]) throw new Error("Article not found");
      await d.insert(comments).values({ articleId: art[0].id, userId: ctx.user.id, body: input.body, parentId: input.parentId ?? null });
      return { success: true };
    }),

  myBookmarks: authedQuery.query(async ({ ctx }) => {
    return db().select({
      id: articles.id, slug: articles.slug, title: articles.title, excerpt: articles.excerpt,
      featuredImage: articles.featuredImage, publishedAt: articles.publishedAt, views: articles.views,
    }).from(bookmarks).innerJoin(articles, eq(bookmarks.articleId, articles.id))
      .where(eq(bookmarks.userId, ctx.user.id)).orderBy(desc(bookmarks.createdAt));
  }),

  toggleBookmark: authedQuery
    .input(z.object({ articleSlug: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const d = db();
      const art = await d.select({ id: articles.id }).from(articles).where(eq(articles.slug, input.articleSlug)).limit(1);
      if (!art[0]) throw new Error("Article not found");
      const existing = await d.select({ id: bookmarks.id }).from(bookmarks)
        .where(sql`${bookmarks.userId} = ${ctx.user.id} AND ${bookmarks.articleId} = ${art[0].id}`).limit(1);
      if (existing[0]) {
        await d.delete(bookmarks).where(eq(bookmarks.id, existing[0].id));
        return { bookmarked: false };
      }
      await d.insert(bookmarks).values({ userId: ctx.user.id, articleId: art[0].id });
      return { bookmarked: true };
    }),

  bookmarkStatus: authedQuery.input(z.object({ articleSlug: z.string() })).query(async ({ ctx, input }) => {
    const d = db();
    const art = await d.select({ id: articles.id }).from(articles).where(eq(articles.slug, input.articleSlug)).limit(1);
    if (!art[0]) return { bookmarked: false };
    const existing = await d.select({ id: bookmarks.id }).from(bookmarks)
      .where(sql`${bookmarks.userId} = ${ctx.user.id} AND ${bookmarks.articleId} = ${art[0].id}`).limit(1);
    return { bookmarked: !!existing[0] };
  }),

  contact: publicQuery
    .input(z.object({ name: z.string().min(2).max(120), email: z.string().email(), message: z.string().min(10).max(4000) }))
    .mutation(async () => ({ success: true })),

  // ---- Admin ----
  adminMeta: adminQuery.query(async () => {
    const d = db();
    const { authors, categories } = await import("@db/schema");
    const [a, c] = await Promise.all([d.select().from(authors), d.select().from(categories)]);
    return { authors: a, categories: c };
  }),

  adminStats: adminQuery.query(async () => {
    const d = db();
    const [a, c, s, u] = await Promise.all([
      d.select({ n: sql<number>`COUNT(*)` }).from(articles),
      d.select({ n: sql<number>`COUNT(*)` }).from(comments),
      d.select({ n: sql<number>`COUNT(*)` }).from(newsletterSubscribers),
      d.select({ n: sql<number>`COUNT(*)` }).from(users),
    ]);
    return { articles: Number(a[0].n), comments: Number(c[0].n), subscribers: Number(s[0].n), users: Number(u[0].n) };
  }),

  adminArticles: adminQuery.query(async () => {
    const d = db();
    return d.select({
      id: articles.id, slug: articles.slug, title: articles.title, status: articles.status,
      views: articles.views, publishedAt: articles.publishedAt, featuredImage: articles.featuredImage,
      categoryName: sql<string>`(SELECT name FROM categories WHERE categories.id = ${articles.categoryId})`,
      authorName: sql<string>`(SELECT name FROM authors WHERE authors.id = ${articles.authorId})`,
    }).from(articles).orderBy(desc(articles.updatedAt)).limit(200);
  }),

  adminArticle: adminQuery.input(z.object({ id: z.number().int() })).query(async ({ input }) => {
    const rows = await db().select().from(articles).where(eq(articles.id, input.id)).limit(1);
    return rows[0] ?? null;
  }),

  adminSaveArticle: adminQuery
    .input(z.object({
      id: z.number().int().optional(),
      slug: z.string().min(2).max(255),
      title: z.string().min(2).max(512),
      excerpt: z.string().max(1000).optional().default(""),
      body: z.string().min(2),
      categoryId: z.number().int(),
      authorId: z.number().int(),
      featuredImage: z.string().max(512).optional().default(""),
      status: z.enum(["draft", "published"]),
      publishedAt: z.date().optional().nullable(),
    }))
    .mutation(async ({ input }) => {
      const d = db();
      const publishedAt = input.status === "published" ? (input.publishedAt ?? new Date()) : null;
      if (input.id) {
        await d.update(articles).set({
          slug: input.slug, title: input.title, excerpt: input.excerpt, body: input.body,
          categoryId: input.categoryId, authorId: input.authorId, featuredImage: input.featuredImage,
          status: input.status, publishedAt,
        }).where(eq(articles.id, input.id));
        return { id: input.id };
      }
      const res = await d.insert(articles).values({
        slug: input.slug, title: input.title, excerpt: input.excerpt, body: input.body,
        categoryId: input.categoryId, authorId: input.authorId, featuredImage: input.featuredImage,
        status: input.status, publishedAt,
      });
      return { id: Number(res[0].insertId) };
    }),

  adminDeleteArticle: adminQuery.input(z.object({ id: z.number().int() })).mutation(async ({ input }) => {
    await db().delete(articles).where(eq(articles.id, input.id));
    return { success: true };
  }),

  adminSubscribers: adminQuery.query(async () => {
    return db().select().from(newsletterSubscribers).orderBy(desc(newsletterSubscribers.subscribedAt)).limit(500);
  }),
});
