import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  bigint,
  uniqueIndex,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const authors = mysqlTable("authors", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  bio: text("bio"),
  avatar: varchar("avatar", { length: 512 }),
  role: varchar("role", { length: 128 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const categories = mysqlTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  slug: varchar("slug", { length: 128 }).notNull().unique(),
  color: varchar("color", { length: 32 }).notNull(),
  description: text("description"),
});

export const articles = mysqlTable("articles", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 512 }).notNull(),
  excerpt: text("excerpt"),
  body: text("body").notNull(),
  categoryId: bigint("categoryId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => categories.id),
  authorId: bigint("authorId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => authors.id),
  featuredImage: varchar("featuredImage", { length: 512 }),
  status: mysqlEnum("status", ["draft", "published"]).default("draft").notNull(),
  publishedAt: timestamp("publishedAt"),
  views: int("views").default(0).notNull(),
  popularityScore: bigint("popularityScore", { mode: "number" }).default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export const comments = mysqlTable(
  "comments",
  {
    id: serial("id").primaryKey(),
    articleId: bigint("articleId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => articles.id),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    parentId: bigint("parentId", { mode: "number", unsigned: true }),
    body: text("body").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => [uniqueIndex("comment_article_user").on(t.articleId, t.userId, t.parentId, t.createdAt)],
);

export const bookmarks = mysqlTable(
  "bookmarks",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    articleId: bigint("articleId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => articles.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => [uniqueIndex("bookmark_user_article").on(t.userId, t.articleId)],
);

export const newsletterSubscribers = mysqlTable(
  "newsletter_subscribers",
  {
    id: serial("id").primaryKey(),
    email: varchar("email", { length: 320 }).notNull().unique(),
    subscribedAt: timestamp("subscribedAt").defaultNow().notNull(),
  },
);

export const articleViews = mysqlTable(
  "article_views",
  {
    id: serial("id").primaryKey(),
    articleId: bigint("articleId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => articles.id),
    viewerKey: varchar("viewerKey", { length: 128 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => [uniqueIndex("view_article_viewer").on(t.articleId, t.viewerKey)],
);

export const matches = mysqlTable("matches", {
  id: serial("id").primaryKey(),
  game: varchar("game", { length: 64 }).notNull(),
  teamA: varchar("teamA", { length: 128 }).notNull(),
  teamB: varchar("teamB", { length: 128 }).notNull(),
  teamAScore: int("teamAScore"),
  teamBScore: int("teamBScore"),
  status: mysqlEnum("status", ["upcoming", "live", "finished"]).notNull(),
  startTime: timestamp("startTime").notNull(),
  event: varchar("event", { length: 255 }),
  notes: varchar("notes", { length: 512 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Article = typeof articles.$inferSelect;
export type Author = typeof authors.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type Match = typeof matches.$inferSelect;
