import { getDb } from "../api/queries/connection";
import { articles, authors, categories, matches } from "./schema";

const DAYS = 24 * 60 * 60 * 1000;

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  const existing = await db.select({ id: categories.id }).from(categories).limit(1);
  if (existing.length > 0) {
    console.log("Already seeded, skipping.");
    process.exit(0);
  }

  await db.insert(categories).values([
    { name: "News", slug: "news", color: "news", description: "Breaking stories from across the gaming industry." },
    { name: "Esports", slug: "esports", color: "esports", description: "Pro play, tournaments, rosters and results." },
    { name: "Guides", slug: "guides", color: "guides", description: "Practical how-tos, builds and improvement routines." },
    { name: "Reviews", slug: "reviews", color: "reviews", description: "Honest verdicts on the games that matter." },
    { name: "Entertainment", slug: "entertainment", color: "entertainment", description: "Streaming culture, creators and events." },
    { name: "Tech", slug: "tech", color: "tech", description: "Hardware, benchmarks and the machines we play on." },
    { name: "Opinions", slug: "opinions", color: "opinions", description: "Sharp takes and editorials on gaming culture." },
  ]);

  await db.insert(authors).values([
    { name: "Maya Chen", slug: "maya-chen", bio: "Maya covers competitive FPS and the business of esports. Previously desk analyst for two VCT seasons.", avatar: "/images/articles/val-masters.png", role: "Esports Reporter" },
    { name: "Jordan Okafor", slug: "jordan-okafor", bio: "Jordan writes guides and features focused on getting readers measurably better at the games they love.", avatar: "/images/articles/aim-guide.png", role: "Guides Editor" },
    { name: "Priya Raman", slug: "priya-raman", bio: "Priya leads reviews. If a game wastes your time or money, she will tell you — and show her work.", avatar: "/images/articles/wukong.png", role: "Reviews Lead" },
  ]);

  const cats = await db.select().from(categories);
  const cat = (slug: string) => cats.find((c) => c.slug === slug)!.id;
  const A = { maya: 1, jordan: 2, priya: 3 };

  const img = (n: string) => `/images/articles/${n}.png`;

  const now = Date.now();
  await db.insert(articles).values([
    {
      slug: "cs2-summer-update-shakes-up-meta", title: "CS2's Summer Update Quietly Rewrote the Entire Meta", categoryId: cat("news"), authorId: A.maya,
      excerpt: "One smoke change, one rifle tweak, and a subtick fix later — every top team's playbook looks different this month.",
      featuredImage: img("cs2-meta"), status: "published", publishedAt: new Date(now - 1 * DAYS), views: 48210,
      body: `When Valve shipped the summer update for Counter-Strike 2, the patch notes looked almost boring. A smoke height adjustment. A small accuracy change to the M4A1-S. A handful of bug fixes that most players scrolled past.\n\nThree weeks later, the competitive landscape barely resembles the one we had in July.\n\n## The smoke that changed everything\n\nThe single biggest shift came from a change nobody asked for: smokes now bloom slightly lower on Overpass and Vertigo. On paper, it's a cosmetic fix. In practice, it killed the default B execute that three of the top five teams had built their entire T-sides around.\n\n"We scrapped two months of prep in a weekend," one Tier 1 coach told me on condition of anonymity. "The lanes we used to take for granted just don't exist anymore."\n\n## The M4A1-S buff nobody predicted\n\nThe rifle's crouch accuracy buff looked minor until the data came in. In the first two weeks of top-tier play, CT-side rifle kill share jumped nearly four points — the largest single-patch swing since the AUG meta of 2019.\n\n## What to watch next\n\nIf the current trends hold, expect a wave of map vetoes favoring Ancient and Anubis, where the new smoke behavior matters least. The teams adapting fastest are, unsurprisingly, the ones with deeper analyst benches — and that's a worrying sign for the scene's middle class.`,
    },
    {
      slug: "gta-vi-trailer-breaks-records", title: "GTA VI Trailer Breaks Viewership Records — Again", categoryId: cat("news"), authorId: A.maya,
      excerpt: "Rockstar's second trailer didn't just beat its own record. It lapped the entire entertainment industry.",
      featuredImage: img("gta6"), status: "published", publishedAt: new Date(now - 2 * DAYS), views: 91300,
      body: `At this point, calling GTA VI a video game feels like calling the Super Bowl a football match. The second trailer pulled in over 100 million views in its first 24 hours, comfortably beating every film trailer in history.\n\n## The numbers are absurd\n\nFor context: the previous record holder for a game trailer was Rockstar's own first GTA VI reveal. The studio is now competing exclusively with itself, and winning.\n\nEngagement metrics tell the stranger story. Average watch time sits above 90 seconds for a two-minute trailer — a retention rate that most creators would trade a limb for. The comment section reads less like hype and more like a cultural event in real time.\n\n## Why it matters\n\nPublishers have spent a decade chasing live-service engagement. Rockstar just demonstrated that pure, single-player spectacle still commands the largest audience on earth. Every earnings call in Q3 is going to mention this trailer.\n\nThere's still no firm release date beyond the widely expected window. But one thing is clear: when GTA VI does ship, it won't be a game launch. It will be a moment.`,
    },
    {
      slug: "sentinels-vs-fnatic-valorant-masters-final", title: "Sentinels Stun Fnatic in a Masters Final for the Ages", categoryId: cat("esports"), authorId: A.maya,
      excerpt: "Five maps. Two overtimes. One 19-year-old nobody had circled on their scouting report.",
      featuredImage: img("val-masters"), status: "published", publishedAt: new Date(now - 3 * DAYS), views: 66700,
      body: `Nobody gave Sentinels a chance against Fnatic's superteam. Twenty-two rounds of Icebox later, everyone in the arena knew they'd witnessed something rare.\n\n## The rookie nobody scouted\n\nSentinels' 19-year-old sixth man was supposed to be a feel-good story, not the story. He finished the series with a 1.31 rating and two clutch wins in overtime — the kind of performance that gets VODs studied for years.\n\nFnatic's stars didn't choke; they were simply out-called. Sentinels' coach won the tactical battle on three of five maps, rotating early on every anti-eco and daring Fnatic to punish it. They couldn't.\n\n## What this means for the circuit\n\nThe win breaks Fnatic's streak of seven consecutive grand final appearances and blows the Championship race wide open. Sentinels vault from sixth to second in circuit points, with two events left on the calendar.\n\n"We knew the whole season people counted us out," the rookie said post-match, still holding the trophy like he wasn't sure it was real. "We just needed five maps to prove it."\n\nThe rematch can't come soon enough.`,
    },
    {
      slug: "t1-faker-league-worlds-comeback", title: "Faker and T1 Complete the Unlikeliest Run in Worlds History", categoryId: cat("esports"), authorId: A.maya,
      excerpt: "From fifth seed to world champions — and a legacy that somehow got bigger.",
      featuredImage: img("faker-worlds"), status: "published", publishedAt: new Date(now - 5 * DAYS), views: 58900,
      body: `Every year, analysts write the same obituary for T1. Every year, Faker makes them delete it.\n\n## The run nobody predicted\n\nT1 entered the tournament as Korea's fifth seed — historically a death sentence. The group stage did nothing to change minds: a 2-1 record, shaky mid-game, and a bot lane that looked out of sync.\n\nThen the knockouts started, and a different team appeared.\n\n## The final that broke records\n\nThe five-game final against the LPL's first seed peaked at 6.4 million concurrent viewers, the most-watched match in League of Legends history. Faker's Game 5 Azir performance — 11/1/9, two game-winning shurima shuffles — is already being called the single greatest game of his career, which is a sentence that shouldn't be possible in year eleven.\n\n## Legacy, quantified\n\nFive world titles. Ten years apart between the first and the last. No player in any major sport has a comparable arc — dominant, written off, and dominant again a decade later.\n\n"He's not the GOAT anymore," one rival mid laner said. "He's the sport."\n\nThe scariest part? He says he's not done.`,
    },
    {
      slug: "valorant-aim-routine-pro-guide", title: "The 20-Minute Aim Routine That Actually Works in Valorant", categoryId: cat("guides"), authorId: A.jordan,
      excerpt: "Stop grinding mindless deathmatch. Pro aim coaches agree on a short, structured routine — here's exactly how to run it.",
      featuredImage: img("aim-guide"), status: "published", publishedAt: new Date(now - 4 * DAYS), views: 35400,
      body: `Most players practice aim the way hamsters run on wheels: lots of effort, zero destination. After talking to three professional aim coaches, a pattern emerged — they all teach variations of the same 20-minute routine.\n\n## Minutes 0–5: Smooth tracking\n\nStart in the range with a vandal, no armor, bots set to strafe. The goal isn't speed — it's eliminating jitter. Move your crosshair in one continuous line. If you find yourself micro-correcting, slow down. Speed without smoothness is just missing faster.\n\n## Minutes 5–12: Microflicks\n\nSwitch to a guardian. Stand still, flick to each bot's head, one bullet, reset. The guardian punishes spray habits and forces clean first-bullet accuracy — the single most important skill in ranked.\n\n## Minutes 12–17: Deathmatch with a constraint\n\nOne deathmatch, one rule: you may not stop moving. Most ranked players die standing still, and it's not an aim problem — it's a habit problem.\n\n## Minutes 17–20: Review\n\nRewatch your deathmatch. Note every death where you were standing still or holding a lazy angle. That's tomorrow's focus.\n\n## The boring truth\n\nTwenty focused minutes daily beats two hours of autopilot. Consistency is the entire meta.`,
    },
    {
      slug: "elden-ring-shadow-builds-beginner", title: "Five Shadow of the Erdtree Builds That Carry Beginners", categoryId: cat("guides"), authorId: A.jordan,
      excerpt: "The DLC's difficulty spike is real. These builds trivialize it — no shame, all results.",
      featuredImage: img("elden-builds"), status: "published", publishedAt: new Date(now - 6 * DAYS), views: 28900,
      body: `Shadow of the Erdtree does not care about your feelings. Its opening boss has ended more runs than every Souls tutorial combined. But FromSoft always leaves a door open for prepared players — here are five keys.\n\n## 1. The Bleed Reaper\n\nScythe-class weapons with innate bleed, stacked with the White Mask and Lord of Blood's Exultation. Bosses melt before they finish their first phase transition. It's unglamorous. It works.\n\n## 2. Faithful Summoner\n\nThe DLC's spirit ash upgrades are criminally underrated. A maxed-up Mimic Tear with a buff-heavy build turns every boss fight into a 2v1 — in your favor, for once.\n\n## 3. Lightning Lance\n\nMessmer's soldiers are weak to lightning. The new lance weapon class gives you reach, poise damage, and a moveset that trivializes shielded enemies.\n\n## 4. The Scarlet Rot Tourist\n\nSlow, cowardly, and undefeated. Rot breath, keep your distance, enjoy the scenery while bosses die on a timer.\n\n## 5. Pure Vigor\n\nSometimes the best build is 60 Vigor and humility. Level your health, upgrade your flask, learn the dodge timing. Old-fashioned, but the DLC respects it.\n\nWhichever you pick: collect the Scadutree Blessings first. Damage scaling in the DLC makes base-game stats matter less than you'd think.`,
    },
    {
      slug: "astro-bot-review", title: "Astro Bot Review: The Best Platformer in a Decade", categoryId: cat("reviews"), authorId: A.priya,
      excerpt: "A small robot carries the entire weight of PlayStation's legacy on his back — and never stumbles.",
      featuredImage: img("astro-bot"), status: "published", publishedAt: new Date(now - 7 * DAYS), views: 41200,
      body: `I've reviewed over sixty platformers in my career. Astro Bot is the first one since 2017 that made me forget I was working.\n\n## Joy, engineered\n\nEvery level in Astro Bot introduces one idea, explores it for ninety seconds, and retires it before it overstays. It's a design philosophy straight out of Miyamoto's playbook — and executed with a confidence that puts most of Nintendo's own output to shame.\n\nThe DualSense integration deserves special mention. I've rolled my eyes at haptic gimmicks for four years. Astro Bot is the first game that made me feel sand, rain, and glass through a controller, and the first where I actively noticed absence when I switched to another game.\n\n## The nostalgia question\n\nYes, it's a parade of PlayStation history. Yes, it's corporate nostalgia as gameplay mechanic. It's also handled with such evident love that even this cynical reviewer got misty at a certain PS2-era cameo.\n\n## Verdict\n\nAstro Bot is a 9.5 — a masterclass in restraint, polish, and pure mechanical joy. It's the reason platformers exist. Don't sleep on it because it looks like a kids' game; it's the best game on PS5, full stop.`,
    },
    {
      slug: "black-myth-wukong-review", title: "Black Myth: Wukong Review — A Flawed, Glorious Epic", categoryId: cat("reviews"), authorId: A.priya,
      excerpt: "The most visually stunning action game ever made is held back by frustrations you'll mostly forgive.",
      featuredImage: img("wukong"), status: "published", publishedAt: new Date(now - 9 * DAYS), views: 52300,
      body: `Black Myth: Wukong is the kind of game that silences review meetings. Screenshots don't do it justice; nothing does.\n\n## The combat is a revelation\n\nGame Science built a stance-and-spell system around Sun Wukong's shapeshifting myths, and the result is action combat with genuine tactical texture. Switching stances mid-combo — light to heavy to a perfectly-timed deflection — feels like conducting violence as music.\n\n## The frustrations are real\n\nThe level design is a maze of beautiful dead ends. The enemy placement sometimes feels adversarial. And the final act's spike in damage-check encounters will test your patience more than your skill.\n\nNone of it matters as much as it should, because the highs are unreachable by other games. The boss fights — and there are dozens — are the best in the genre since Sekiro.\n\n## Verdict\n\nAn 8.5 with a bullet. Flawed, uneven, and utterly unforgettable. Games this ambitious don't come around often; cherish it, warts and all.`,
    },
    {
      slug: "twitch-streamer-breaks-record", title: "A Sleepy Cat Streamer Just Broke the All-Time Hype Train Record", categoryId: cat("entertainment"), authorId: A.jordan,
      excerpt: "Forty-one hours of non-stop gifting. 14 million bits. The streamer slept through the final hour.",
      featuredImage: img("twitch-record"), status: "published", publishedAt: new Date(now - 8 * DAYS), views: 44500,
      body: `The largest Hype Train in Twitch history happened last Tuesday, and the streamer at the center of it missed the finale — because she'd fallen asleep at her desk.\n\n## How it happened\n\nWhat started as a normal 12-hour anniversary stream became something else entirely around hour nine, when a single anonymous donor kicked off a Tier 3 gifting spree. The community responded the way internet communities do: by refusing to let it end.\n\nThe train rolled through 41 hours, surviving two platform-wide outages and one emergency moderation shift change. Viewers set up relay schedules to keep subs rolling while the streamer — known for her aggressively normal content, mostly cat videos and cozy games — dozed off around hour 38.\n\n## The numbers\n\n14.2 million bits. Over 22,000 gifted subs. Peak concurrent viewership of 340,000 — numbers that rival major esports finals.\n\n## Why it matters\n\nThe record wasn't set by a superstar or a corporate channel. It was set by a community that decided, collectively, to build something absurd together. In an era of optimized, engagement-farmed content, that's genuinely moving — and a reminder of what made streaming magical in the first place.\n\nShe woke up to the record, 40,000 new subscribers, and a very confused cat.`,
    },
    {
      slug: "gaming-awards-nominees-announced", title: "Game Awards 2026 Nominations: The Snubs and Surprises", categoryId: cat("entertainment"), authorId: A.jordan,
      excerpt: "Eight nominees for Game of the Year, two shocking omissions, and one indie nobody predicted.",
      featuredImage: img("game-awards"), status: "published", publishedAt: new Date(now - 10 * DAYS), views: 37800,
      body: `The Game Awards nominations dropped this morning, and as always, the omissions are generating more conversation than the inclusions.\n\n## The big surprises\n\nAn indie roguelite with a $2M budget cracked Game of the Year against four $100M+ productions — the first indie GOTY nominee in five years. Its director found out via a text from his mom, who'd seen it on the morning news.\n\nEqually surprising: the expansion-to-full-game contender that the jury explicitly ruled eligible this year, opening a door future publishers will absolutely abuse.\n\n## The snubs\n\nTwo absences sting. The year's best-reviewed JRPG missed GOTY entirely, landing only in score and art categories — a repeat of a pattern genre fans know too well. And a certain live-service comeback story was shut out despite dominating player counts for eight months.\n\n## What to watch\n\nWith eight GOTY nominees and a split vote almost guaranteed, expect the narrative categories — directing and writing — to be better predictors of the final outcome than the marquee race itself.\n\nThe ceremony airs in December. The discourse, as always, has already started.`,
    },
    {
      slug: "rtx-5090-benchmarks-real-world", title: "RTX 5090 Benchmarks: Breathtaking, Absurd, and Nowhere Near Worth It", categoryId: cat("tech"), authorId: A.priya,
      excerpt: "We spent two weeks with the fastest GPU ever made. Our verdict: wait for literally anything else.",
      featuredImage: img("rtx5090"), status: "published", publishedAt: new Date(now - 11 * DAYS), views: 49100,
      body: `The RTX 5090 is the fastest graphics card ever made. It's also $2,000, demands a power supply upgrade, and will make you rethink your life choices — mostly the one where you bought it.\n\n## The performance reality\n\nAt 4K native, the card is genuinely generational: 40-60% faster than the 4090 in our test suite, with path-traced Cyberpunk finally holding triple digits. Frame generation feels less like a trick and more like a genuine feature now.\n\n## The problems\n\nTwelveVHPWR connector anxiety is back. Our sample pulled 575W under load, turning our test bench into a space heater. And at 1440p — where most PC gamers actually play — CPU bottlenecks erase half the card's advantage.\n\n## The value equation\n\nPerformance per dollar actually regressed versus the 4090's launch pricing. This card exists for a specific buyer: 4K/240Hz monitor owners with disposable income and no patience.\n\nFor everyone else, the 5080 and the used 4090 market are the story. The 5090 is a marvel of engineering you should admire from a safe financial distance.\n\nScore: 8/10 for the silicon. 4/10 for the proposition.`,
    },
    {
      slug: "handheld-pc-war-steam-deck-vs-ally-x", title: "The Handheld PC War: Steam Deck OLED vs ROG Ally X — 2026 Edition", categoryId: cat("tech"), authorId: A.priya,
      excerpt: "Two years of firmware updates later, the answer is finally clear — and it depends on who you are.",
      featuredImage: img("handheld-war"), status: "published", publishedAt: new Date(now - 12 * DAYS), views: 31600,
      body: `The handheld PC market has matured, and the binary "Steam Deck or Ally" debate has evolved into something more interesting: which compromises fit your actual life.\n\n## The battery reality\n\nBoth devices now deliver genuine three-to-six hour sessions in AAA games thanks to better firmware and frame limiters. The Ally X's 80Wh battery remains the class leader, but the Deck's efficiency in SteamOS narrows the gap more than spec sheets suggest.\n\n## The software question\n\nSteamOS is still the best handheld operating system — suspend/resume that actually works, a controller-first UI, and Proton compatibility that's frankly embarrassing for Windows. The Ally's Windows 11 experience has improved, but it's lipstick on a desktop OS.\n\n## The verdict\n\nBuy the Steam Deck OLED if you play mostly Steam games and value simplicity. Buy the Ally X if you live in Game Pass, play competitive titles with anti-cheat, or need the extra horsepower for emulation. Buy neither and wait if you can — next-gen chips promise this whole category again within a year.\n\nThere's no wrong answer anymore. That's the best news the category has ever had.`,
    },
    {
      slug: "live-service-fatigue-opinion", title: "Opinion: Live-Service Fatigue Is the Industry's Slow-Motion Crash", categoryId: cat("opinions"), authorId: A.jordan,
      excerpt: "Every publisher chased the forever-game. Now the forever-games are the ones players are leaving.",
      featuredImage: img("live-service"), status: "published", publishedAt: new Date(now - 13 * DAYS), views: 60300,
      body: `For a decade, the industry's highest aspiration was the forever-game: one title, monetized endlessly, updated forever. In 2026, we can count the successes on one hand — and the casualties in the hundreds.\n\n## The math stopped working\n\nA live-service game needs a critical mass of players to survive, which means every new release is competing with every existing one for the same finite attention. Publishers built an ecosystem where their own products cannibalize each other, then acted surprised when the chart-toppers stayed chart-toppers.\n\nThe human cost is worse. Studios ship crunch to hit seasonal content cadences, then get gutted when metrics slip. The forever-game model treats developers as content machines — and burns them out on a schedule.\n\n## What players actually want\n\nLook at what succeeds now: finite, polished, complete experiences. Players aren't abandoning games; they're abandoning obligations. Logging in shouldn't feel like a second job with a storefront.\n\n## The way forward\n\nThe industry doesn't need more live-service games. It needs publishers willing to make a great thing, sell it once, and let it end. That's not nostalgia — it's the only economics that consistently work.\n\nThe crash won't be loud. It's already happening, one sunsetted server at a time.`,
    },
    {
      slug: "esports-belong-olympics-opinion", title: "Opinion: Esports Don't Belong in the Olympics — They Don't Need to", categoryId: cat("opinions"), authorId: A.maya,
      excerpt: "Chasing Olympic validation misunderstands what makes esports powerful. The kids already know.",
      featuredImage: img("esports-olympics"), status: "published", publishedAt: new Date(now - 14 * DAYS), views: 52700,
      body: `Every few years, the esports world indulges the same fantasy: Olympic legitimacy. Medals, flags, the whole apparatus of state-sanctioned sport. It's a nice idea. It's also completely backwards.\n\n## The Olympics need esports, not the reverse\n\nOlympic viewership skews older every cycle. The IOC knows it. That's why esports keeps appearing in the "demonstration" slot — the Olympic equivalent of being asked to the party to make the hosts look cool.\n\nBut esports doesn't lack legitimacy. The Worlds final out-drew the Super Bowl in peak concurrent viewers. Valorant Masters sells out arenas in minutes. A generation of fans already treats these events with the reverence their parents reserved for the Olympics.\n\n## What we'd lose\n\nOlympic standardization would sand esports down to nothing. Publisher-owned games, patch-dependent metas, roster shuffles mid-season — the things that make esports alive are the things Olympic bureaucracy cannot tolerate.\n\n## Build our own institutions\n\nThe answer isn't joining an old system. It's building better ones: player unions that actually have power, circuit structures that don't collapse when a publisher pivots, and events rooted in community rather than committee.\n\nEsports doesn't need the Olympics' permission to matter. It never did.`,
    },
  ]);

  await db.insert(matches).values([
    { game: "Valorant", teamA: "Sentinels", teamB: "Fnatic", teamAScore: 3, teamBScore: 2, status: "finished", startTime: new Date(now - 3 * DAYS), event: "VCT Masters Shanghai", notes: "Grand Final — 5 maps" },
    { game: "Valorant", teamA: "Paper Rex", teamB: "LOUD", status: "live", startTime: new Date(now - 2 * 3600 * 1000), event: "VCT Masters Shanghai", notes: "Map 2 — Lotus" },
    { game: "CS2", teamA: "Natus Vincere", teamB: "G2 Esports", status: "live", startTime: new Date(now - 1 * 3600 * 1000), event: "BLAST Premier Fall", notes: "Map 1 — Inferno" },
    { game: "League of Legends", teamA: "T1", teamB: "JD Gaming", teamAScore: 3, teamBScore: 1, status: "finished", startTime: new Date(now - 5 * DAYS), event: "Worlds 2026 Final" },
    { game: "Apex Legends", teamA: "TSM", teamB: "DarkZero", status: "upcoming", startTime: new Date(now + 1 * DAYS), event: "ALGS Split 2 Playoffs" },
    { game: "Valorant", teamA: "DRX", teamB: "Leviatán", status: "upcoming", startTime: new Date(now + 2 * DAYS), event: "VCT Masters Shanghai" },
    { game: "CS2", teamA: "Team Spirit", teamB: "Vitality", status: "upcoming", startTime: new Date(now + 3 * DAYS), event: "BLAST Premier Fall" },
    { game: "League of Legends", teamA: "Gen.G", teamB: "Bilibili Gaming", status: "upcoming", startTime: new Date(now + 4 * DAYS), event: "KeSPA Cup" },
  ]);

  console.log("Done. Seeded", 14, "articles.");
  process.exit(0);
}

seed().catch((e) => {
  console.error(e);
  process.exit(1);
});
