export type CategoryInfo = { id: number; name: string; slug: string; color: string };
export type AuthorInfo = { id: number; name: string; slug: string; avatar: string | null; role: string | null; bio?: string | null };

export type ArticleCard = {
  id: number;
  slug: string;
  title: string;
  excerpt: string | null;
  featuredImage: string | null;
  views: number;
  publishedAt: Date | null;
  category: CategoryInfo;
  author: AuthorInfo;
};

export type ArticleFull = ArticleCard & { body: string; status: string };

export type MatchItem = {
  id: number;
  game: string;
  teamA: string;
  teamB: string;
  teamAScore: number | null;
  teamBScore: number | null;
  status: "upcoming" | "live" | "finished";
  startTime: Date;
  event: string | null;
  notes: string | null;
};

export function formatDate(d: Date | null | undefined): string {
  if (!d) return "";
  return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

export function readTime(body: string): number {
  return Math.max(2, Math.round(body.split(/\s+/).length / 200));
}

export function formatViews(v: number): string {
  if (v >= 1_000_000) return (v / 1_000_000).toFixed(1) + "M";
  if (v >= 1_000) return (v / 1_000).toFixed(1) + "K";
  return String(v);
}
