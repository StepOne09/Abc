import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "react-router";
import { Clock, Eye, Share2, Twitter, Facebook, Bookmark, BookmarkCheck, MessageSquare, Send } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { CategoryTag, CardSmall } from "@/components/ArticleCard";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import { formatDate, formatViews, readTime } from "@/types";

function slugify(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

function useProgress() {
  const [p, setP] = useState(0);
  useEffect(() => {
    const fn = () => {
      const el = document.documentElement;
      const total = el.scrollHeight - el.clientHeight;
      setP(total > 0 ? Math.min(1, el.scrollTop / total) : 0);
    };
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);
  return p;
}

function renderBody(body: string) {
  return body.split(/\n\n+/).map((para, i) => {
    if (para.startsWith("## ")) {
      const h = para.slice(3).trim();
      return <h2 key={i} id={slugify(h)} className="gg-h3 mt-10 mb-3 scroll-mt-24">{h}</h2>;
    }
    return <p key={i} className="my-4 leading-relaxed text-[1.05rem] text-[color-mix(in_srgb,var(--gg-text)_88%,transparent)]">{para}</p>;
  });
}

export default function ArticlePage() {
  const { slug = "" } = useParams();
  const { data, isLoading } = trpc.articles.bySlug.useQuery({ slug });
  const progress = useProgress();
  const { isAuthenticated } = useAuth();
  const viewed = useRef(false);
  const [copied, setCopied] = useState(false);
  const [comment, setComment] = useState("");
  const [replyTo, setReplyTo] = useState<number | null>(null);

  const recordView = trpc.articles.recordView.useMutation();
  useEffect(() => {
    if (data?.article && !viewed.current) {
      viewed.current = true;
      let key = sessionStorage.getItem("gg-viewer");
      if (!key) {
        key = crypto.randomUUID();
        sessionStorage.setItem("gg-viewer", key);
      }
      recordView.mutate({ slug, viewerKey: key });
    }
  }, [data?.article, slug]);

  const { data: comments } = trpc.articles.comments.useQuery({ articleSlug: slug });
  const addComment = trpc.site.addComment.useMutation();
  const { data: bm } = trpc.site.bookmarkStatus.useQuery({ articleSlug: slug }, { enabled: isAuthenticated });
  const toggleBm = trpc.site.toggleBookmark.useMutation();
  const utils = trpc.useUtils();

  const headings = useMemo(
    () => (data?.article?.body ?? "").split(/\n\n+/).filter((l) => l.startsWith("## ")).map((l) => l.slice(3).trim()),
    [data?.article?.body],
  );

  useEffect(() => {
    document.title = data?.article ? `${data.article.title} — GGWIRE` : "GGWIRE";
    const ld = {
      "@context": "https://schema.org",
      "@type": "Article",
      headline: data?.article?.title,
      image: data?.article?.featuredImage,
      datePublished: data?.article?.publishedAt,
      author: { "@type": "Person", name: data?.article?.author.name },
      publisher: { "@type": "Organization", name: "GGWIRE" },
    };
    const s = document.createElement("script");
    s.type = "application/ld+json";
    s.text = JSON.stringify(ld);
    document.head.appendChild(s);
    return () => { document.head.removeChild(s); };
  }, [data?.article]);

  if (isLoading) return <div className="mx-auto max-w-4xl px-4 py-10"><Skeleton className="h-10 w-3/4 mb-4" /><Skeleton className="h-[420px] rounded-xl" /></div>;
  if (!data?.article) return <div className="mx-auto max-w-4xl px-4 py-24 text-center"><p className="gg-h2">Article not found</p><Link to="/" className="text-gg-accent hover:underline">Back to home</Link></div>;

  const a = data.article;
  const url = window.location.href;
  const roots = (comments ?? []).filter((c) => !c.parentId);
  const replies = (cId: number) => (comments ?? []).filter((c) => c.parentId === cId);

  return (
    <article className={`gg-category-${a.category.color}`}>
      <div className="fixed top-0 left-0 right-0 h-1 z-50 bg-transparent">
        <div className="gg-progress-bar h-full bg-gg-accent" style={{ transform: `scaleX(${progress})` }} />
      </div>

      {/* Header */}
      <header className="mx-auto max-w-4xl px-4 pt-12 pb-6 text-center">
        <CategoryTag slug={a.category.slug} name={a.category.name} color={a.category.color} />
        <h1 className="gg-h1 mt-4">{a.title}</h1>
        <p className="mt-4 text-lg text-[var(--gg-text-muted)] max-w-2xl mx-auto">{a.excerpt}</p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-4 text-sm text-[var(--gg-text-muted)]">
          <span className="flex items-center gap-2">
            <img src={a.author.avatar ?? ""} alt="" className="w-8 h-8 rounded-full object-cover" />
            <span className="font-semibold text-[var(--gg-text)]">{a.author.name}</span>
          </span>
          <span>{formatDate(a.publishedAt)}</span>
          <span className="flex items-center gap-1"><Clock className="w-4 h-4" />{readTime(a.body)} min read</span>
          <span className="flex items-center gap-1"><Eye className="w-4 h-4" />{formatViews(a.views)}</span>
          {isAuthenticated && (
            <button
              className="flex items-center gap-1.5 text-gg-accent hover:underline"
              onClick={() => toggleBm.mutate({ articleSlug: slug }, { onSuccess: () => utils.site.bookmarkStatus.invalidate() })}
            >
              {bm?.bookmarked ? <><BookmarkCheck className="w-4 h-4" />Saved</> : <><Bookmark className="w-4 h-4" />Bookmark</>}
            </button>
          )}
        </div>
      </header>

      <div className="mx-auto max-w-5xl px-4">
        <img src={a.featuredImage ?? ""} alt={a.title} className="w-full aspect-video object-cover rounded-2xl border border-[var(--gg-line)]" />
      </div>

      {/* Body with TOC + share rail */}
      <div className="mx-auto max-w-7xl px-4 py-10 grid lg:grid-cols-[200px_700px_1fr] gap-10">
        <aside className="hidden lg:block">
          <div className="sticky top-24 space-y-6">
            {headings.length > 0 && (
              <nav>
                <p className="text-xs font-bold uppercase tracking-widest text-[var(--gg-text-muted)] mb-3">On this page</p>
                <ul className="space-y-2 text-sm border-l border-[var(--gg-line)]">
                  {headings.map((h) => (
                    <li key={h}><a href={`#${slugify(h)}`} className="block pl-3 -ml-px border-l-2 border-transparent hover:border-gg-accent hover:text-gg-accent transition-colors text-[var(--gg-text-muted)]">{h}</a></li>
                  ))}
                </ul>
              </nav>
            )}
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-[var(--gg-text-muted)] mb-3 flex items-center gap-1.5"><Share2 className="w-3.5 h-3.5" />Share</p>
              <div className="flex lg:flex-col gap-2">
                <Button variant="outline" size="sm" onClick={() => window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(a.title)}`, "_blank")}><Twitter className="w-4 h-4 mr-2" />X</Button>
                <Button variant="outline" size="sm" onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, "_blank")}><Facebook className="w-4 h-4 mr-2" />Facebook</Button>
                <Button variant="outline" size="sm" onClick={() => window.open(`https://www.reddit.com/submit?url=${encodeURIComponent(url)}&title=${encodeURIComponent(a.title)}`, "_blank")}>Reddit</Button>
                <Button variant="outline" size="sm" onClick={() => { navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 1500); }}>
                  {copied ? "Copied!" : "Copy link"}
                </Button>
              </div>
            </div>
          </div>
        </aside>

        <div className="max-w-[700px] w-full mx-auto">
          {renderBody(a.body)}

          {/* Author card */}
          <div className="mt-12 rounded-xl border border-[var(--gg-line)] bg-[var(--gg-surface-2)] p-6 flex gap-4">
            <img src={a.author.avatar ?? ""} alt="" className="w-16 h-16 rounded-full object-cover" />
            <div>
              <p className="text-xs uppercase tracking-widest text-[var(--gg-text-muted)]">{a.author.role}</p>
              <p className="gg-h3 mt-0.5">{a.author.name}</p>
              <p className="mt-1 text-sm text-[var(--gg-text-muted)]">{a.author.bio ?? ""}</p>
            </div>
          </div>

          {/* Comments */}
          <section className="mt-12">
            <h2 className="gg-h3 flex items-center gap-2"><MessageSquare className="w-5 h-5 text-gg-accent" />Comments ({comments?.length ?? 0})</h2>
            {isAuthenticated ? (
              <form className="mt-4 space-y-3" onSubmit={(e) => {
                e.preventDefault();
                if (comment.trim().length < 2) return;
                addComment.mutate({ articleSlug: slug, body: comment, parentId: replyTo ?? undefined }, {
                  onSuccess: () => { setComment(""); setReplyTo(null); utils.articles.comments.invalidate(); },
                });
              }}>
                {replyTo && (
                  <p className="text-xs text-gg-accent">Replying to a comment — <button type="button" className="underline" onClick={() => setReplyTo(null)}>cancel</button></p>
                )}
                <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Add your take..." rows={3} />
                <Button type="submit" disabled={addComment.isPending}><Send className="w-4 h-4 mr-2" />Post comment</Button>
              </form>
            ) : (
              <p className="mt-4 text-sm text-[var(--gg-text-muted)]"><Link to="/login" className="text-gg-accent hover:underline">Sign in</Link> to join the discussion.</p>
            )}
            <div className="mt-8 space-y-6">
              {roots.map((c) => (
                <div key={c.id} className="rounded-xl border border-[var(--gg-line)] bg-[var(--gg-surface-2)] p-4">
                  <div className="flex items-center gap-2 text-sm">
                    <span className="font-semibold">{c.user.name}</span>
                    <span className="text-xs text-[var(--gg-text-muted)]">{formatDate(c.createdAt)}</span>
                    {isAuthenticated && (
                      <button className="ml-auto text-xs text-gg-accent hover:underline" onClick={() => setReplyTo(c.id)}>Reply</button>
                    )}
                  </div>
                  <p className="mt-2 text-sm leading-relaxed">{c.body}</p>
                  {replies(c.id).map((r) => (
                    <div key={r.id} className="mt-3 ml-6 pl-4 border-l-2 border-gg-accent/40">
                      <div className="flex items-center gap-2 text-sm">
                        <span className="font-semibold">{r.user.name}</span>
                        <span className="text-xs text-[var(--gg-text-muted)]">{formatDate(r.createdAt)}</span>
                      </div>
                      <p className="mt-1 text-sm leading-relaxed">{r.body}</p>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </section>
        </div>

        <div className="hidden lg:block" />
      </div>

      {/* Related */}
      {data.related.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 pb-16">
          <h2 className="gg-h2 mb-6">More in {a.category.name}</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {data.related.map((r) => <CardSmall key={r.id} a={r} />)}
          </div>
        </section>
      )}
    </article>
  );
}
