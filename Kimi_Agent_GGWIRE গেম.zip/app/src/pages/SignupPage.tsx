import { Link } from "react-router";
import { Zap, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getOAuthUrl } from "@/pages/Login";

const PERKS = ["Comment on any story", "Bookmark articles to read later", "Get the Daily GG newsletter", "First-user admin access for your site demo"];

export default function SignupPage() {
  return (
    <div className="min-h-screen grid place-items-center px-4 bg-[var(--gg-surface)] relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none opacity-30" style={{ background: "radial-gradient(600px 300px at 50% 0%, var(--gg-accent-soft), transparent)" }} />
      <Card className="w-full max-w-md relative border-[var(--gg-line)] bg-[var(--gg-surface-2)]">
        <CardHeader className="text-center">
          <Link to="/" className="mx-auto mb-2 flex items-center gap-2">
            <span className="grid place-items-center w-9 h-9 rounded-md bg-gg-accent text-white"><Zap className="w-5 h-5" fill="currentColor" /></span>
            <span className="gg-display text-2xl font-bold">GG<span className="text-gg-accent">WIRE</span></span>
          </Link>
          <CardTitle>Join GGWIRE</CardTitle>
          <CardDescription>One account for comments, bookmarks and more.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <ul className="space-y-2 text-sm text-[var(--gg-text-muted)]">
            {PERKS.map((p) => (
              <li key={p} className="flex items-center gap-2"><Check className="w-4 h-4 text-gg-accent shrink-0" />{p}</li>
            ))}
          </ul>
          <Button className="w-full" size="lg" onClick={() => { window.location.href = getOAuthUrl(); }}>
            Continue with Kimi
          </Button>
          <p className="text-center text-xs text-[var(--gg-text-muted)]">
            Already have an account? <Link to="/login" className="text-gg-accent hover:underline">Sign in</Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
