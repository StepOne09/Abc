import { useEffect, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { CardRow } from "@/components/ArticleCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";

export default function CategoryPage() {
  const { slug = "" } = useParams();
  const [params, setParams] = useSearchParams();
  const sort = (params.get("sort") as "latest" | "popular") || "latest";
  const [offset, setOffset] = useState(0);

  useEffect(() => { setOffset(0); }, [slug, sort]);

  const { data, isLoading } = trpc.articles.byCategory.useQuery(
    { slug, sort, offset: 0, limit: 9 + offset },
  );

  useEffect(() => {
    document.title = data?.category ? `${data.category.name} — GGWIRE` : "GGWIRE";
  }, [data?.category]);

  const showMore = data ? 9 + offset < data.total : false;

  return (
    <div className={`gg-category-${slug}`}>
      <div className="border-b border-[var(--gg-line)] bg-[var(--gg-surface-2)]">
        <div className="mx-auto max-w-7xl px-4 py-10">
          <p className="text-xs text-[var(--gg-text-muted)] mb-2">
            <Link to="/" className="hover:text-gg-accent">Home</Link> <span className="mx-1">/</span> <span className="text-cat capitalize">{slug}</span>
          </p>
          <h1 className="gg-h1 text-cat capitalize">{data?.category?.name ?? slug}</h1>
          {data?.category?.description && <p className="mt-3 text-[var(--gg-text-muted)] max-w-xl">{data.category.description}</p>}
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-10">
        <div className="flex gap-2 mb-8">
          <Button size="sm" variant={sort === "latest" ? "default" : "outline"} onClick={() => setParams({ sort: "latest" })}>Latest</Button>
          <Button size="sm" variant={sort === "popular" ? "default" : "outline"} onClick={() => setParams({ sort: "popular" })}>Popular</Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-40 rounded-xl" />)}</div>
        ) : data?.items.length === 0 ? (
          <p className="text-[var(--gg-text-muted)]">No stories here yet.</p>
        ) : (
          <>
            <div className="space-y-4">
              {(data?.items ?? []).map((a) => <CardRow key={a.id} a={a} />)}
            </div>
            {showMore && (
              <div className="mt-10 text-center">
                <Button variant="outline" onClick={() => setOffset((o) => o + 6)}>Load more</Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
