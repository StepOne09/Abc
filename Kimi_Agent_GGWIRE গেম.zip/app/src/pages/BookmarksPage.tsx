import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { CardSmall } from "@/components/ArticleCard";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";

export default function BookmarksPage() {
  const { user, isLoading: authLoading } = useAuth({ redirectOnUnauthenticated: true });
  const { data, isLoading } = trpc.site.myBookmarks.useQuery(undefined, { enabled: !!user });

  if (authLoading || (isLoading && user)) {
    return <div className="mx-auto max-w-4xl px-4 py-10 space-y-4">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}</div>;
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-12">
      <h1 className="gg-h1">Your Bookmarks</h1>
      <p className="mt-2 text-[var(--gg-text-muted)]">Saved stories, synced to your account.</p>
      {!user ? null : (data?.length ?? 0) === 0 ? (
        <p className="mt-10 text-sm text-[var(--gg-text-muted)]">
          Nothing saved yet. Tap the bookmark on any article to keep it here — or <Link to="/" className="text-gg-accent hover:underline">start reading</Link>.
        </p>
      ) : (
        <div className="mt-8 grid gap-3">
          {data!.map((b) => (
            <CardSmall key={b.id} a={{
              id: b.id, slug: b.slug, title: b.title, excerpt: b.excerpt, featuredImage: b.featuredImage,
              views: b.views, publishedAt: b.publishedAt,
              category: { id: 0, name: "", slug: "news", color: "news" },
              author: { id: 0, name: "", slug: "", avatar: null, role: null },
            }} />
          ))}
        </div>
      )}
    </div>
  );
}
