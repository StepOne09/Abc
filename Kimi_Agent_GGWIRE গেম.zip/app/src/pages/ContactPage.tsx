import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Check } from "lucide-react";

const schema = z.object({
  name: z.string().min(2, "Please enter your name"),
  email: z.string().email("Please enter a valid email"),
  message: z.string().min(10, "Tell us a bit more (min 10 characters)"),
});

type Values = z.infer<typeof schema>;

export default function ContactPage() {
  const [sent, setSent] = useState(false);
  const contact = trpc.site.contact.useMutation({ onSuccess: () => setSent(true) });
  const form = useForm<Values>({ resolver: zodResolver(schema), defaultValues: { name: "", email: "", message: "" } });

  return (
    <div className="mx-auto max-w-2xl px-4 py-16">
      <p className="text-xs font-bold uppercase tracking-widest text-gg-accent mb-3">Contact</p>
      <h1 className="gg-h1">Talk to the newsroom</h1>
      <p className="mt-3 text-[var(--gg-text-muted)]">
        Tips, corrections, partnership pitches or press releases — this is the door. Tips can be anonymous; we read everything.
      </p>
      {sent ? (
        <div className="mt-10 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-6 flex items-center gap-3">
          <Check className="w-5 h-5 text-emerald-400" />
          <p>Message received. A real human will get back to you within two business days.</p>
        </div>
      ) : (
        <Form {...form}>
          <form className="mt-10 space-y-6" onSubmit={form.handleSubmit((v) => contact.mutate(v))}>
            <FormField control={form.control} name="name" render={({ field }) => (
              <FormItem><FormLabel>Name</FormLabel><FormControl><Input placeholder="Ada Wong" {...field} /></FormControl><FormMessage /></FormItem>
            )} />
            <FormField control={form.control} name="email" render={({ field }) => (
              <FormItem><FormLabel>Email</FormLabel><FormControl><Input type="email" placeholder="you@example.com" {...field} /></FormControl><FormMessage /></FormItem>
            )} />
            <FormField control={form.control} name="message" render={({ field }) => (
              <FormItem><FormLabel>Message</FormLabel><FormControl><Textarea rows={6} placeholder="What's the story?" {...field} /></FormControl><FormMessage /></FormItem>
            )} />
            <Button type="submit" disabled={contact.isPending}>{contact.isPending ? "Sending..." : "Send message"}</Button>
          </form>
        </Form>
      )}
    </div>
  );
}
