export default function AboutPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16">
      <p className="text-xs font-bold uppercase tracking-widest text-gg-accent mb-3">About us</p>
      <h1 className="gg-h1">We cover play like it matters. Because it does.</h1>
      <div className="mt-8 space-y-4 text-[1.05rem] leading-relaxed text-[color-mix(in_srgb,var(--gg-text)_85%,transparent)]">
        <p>GGWIRE launched with a simple observation: gaming is the biggest entertainment medium on earth, and it deserved journalism with the same energy as the games themselves.</p>
        <p>We're reporters who clutch ranked games at midnight. Analysts who've sat through a thousand map vetoes. Critics who will happily tell you a $200M game isn't worth your weekend. Our beats run from breaking news and tournament floors to hardware labs and the culture of streaming.</p>
        <p>Our rules are short: verify before we publish, disclose everything, and never bury the lede. If we get something wrong, we fix it in the open.</p>
        <p>The industry moves fast. So do we. GG — see you in the comments.</p>
      </div>
    </div>
  );
}
