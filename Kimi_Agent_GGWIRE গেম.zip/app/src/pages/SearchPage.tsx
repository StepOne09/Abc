import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router";
import { Search } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { CardSmall } from "@/components/ArticleCard";
import { Input } from "@/components/ui/input";

export default function SearchPage() {
  const [params, setParams] = useSearchParams();
  const q = params.get("q") ?? "";
  const [input, setInput] = useState(q);
  const [debounced, setDebounced] = useState(q);
  const [open, setOpen] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(input.trim()), 300);
    return () => clearTimeout(t);
  }, [input]);

  const { data: results } = trpc.articles.search.useQuery(
    { q: debounced },
    { enabled: debounced.length > 0 },
  );

  useEffect(() => {
    const fn = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", fn);
    return () => document.removeEventListener("mousedown", fn);
  }, []);

  const suggestions = useMemo(() => (results ?? []).slice(0, 6), [results]);

  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="gg-h1 mb-8">Search GGWIRE</h1>
      <div ref={boxRef} className="relative">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--gg-text-muted)]" />
          <Input
            autoFocus
            value={input}
            onChange={(e) => { setInput(e.target.value); setOpen(true); }}
            onFocus={() => setOpen(true)}
            placeholder="Games, teams, hardware, anything..."
            className="pl-10 h-12 text-base bg-[var(--gg-surface-2)]"
          />
        </div>
        {open && debounced.length > 0 && suggestions.length > 0 && (
          <div className="absolute z-30 mt-2 w-full rounded-xl border border-[var(--gg-line)] bg-[var(--gg-surface-2)] shadow-2xl shadow-black/40 overflow-hidden animate-in slide-in-from-top-2">
            {suggestions.map((r) => (
              <button
                key={r.id}
                className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-[var(--gg-surface-3)] transition-colors"
                onClick={() => { setParams({ q: debounced }); setOpen(false); }}
              >
                <img src={r.featuredImage ?? ""} alt="" className="w-16 aspect-video rounded object-cover" />
                <span className="text-sm font-medium line-clamp-2">{r.title}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {q && (
        <div className="mt-10">
          <p className="text-sm text-[var(--gg-text-muted)] mb-4">Results for <span className="text-gg-accent font-semibold">"{q}"</span></p>
          <div className="space-y-3">
            {(results ?? []).length === 0 && <p className="text-sm text-[var(--gg-text-muted)]">No matches. Try a different keyword.</p>}
            {(results ?? []).map((r) => <CardSmall key={r.id} a={r} />)}
          </div>
        </div>
      )}
      {!q && (
        <p className="mt-6 text-sm text-[var(--gg-text-muted)]">
          Try: <Link className="text-gg-accent hover:underline" to="/search?q=valorant">valorant</Link>,{" "}
          <Link className="text-gg-accent hover:underline" to="/search?q=cs2">cs2</Link>,{" "}
          <Link className="text-gg-accent hover:underline" to="/search?q=gta">gta</Link>
        </p>
      )}
    </div>
  );
}
