import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Pencil, Trash2, Users, FileText, MessageSquare, Mail } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate, formatViews } from "@/types";

const IMAGE_OPTIONS = [
  "cs2-meta", "gta6", "val-masters", "faker-worlds", "aim-guide", "elden-builds",
  "astro-bot", "wukong", "twitch-record", "game-awards", "rtx5090", "handheld-war",
  "live-service", "esports-olympics",
];

const schema = z.object({
  id: z.number().optional(),
  slug: z.string().min(2, "Slug required").regex(/^[a-z0-9-]+$/, "Lowercase letters, numbers and dashes only"),
  title: z.string().min(4, "Title required"),
  excerpt: z.string().max(1000).default(""),
  body: z.string().min(20, "Body too short"),
  categoryId: z.number().int().min(1, "Pick a category"),
  authorId: z.number().int().min(1, "Pick an author"),
  featuredImage: z.string().default(""),
  status: z.enum(["draft", "published"]),
});

type Values = z.infer<typeof schema>;

function ArticleEditor({ initial, onDone }: { initial?: Partial<Values>; onDone: () => void }) {
  const utils = trpc.useUtils();
  const { data: meta } = trpc.site.adminMeta.useQuery();
  const { data: full } = trpc.site.adminArticle.useQuery({ id: initial?.id ?? 0 }, { enabled: !!initial?.id && !initial?.body });
  const save = trpc.site.adminSaveArticle.useMutation({
    onSuccess: () => { utils.invalidate(); onDone(); },
  });
  const form = useForm<Values>({
    resolver: zodResolver(schema) as never,
    values: full ? {
      id: full.id, slug: full.slug, title: full.title, excerpt: full.excerpt ?? "",
      body: full.body, categoryId: full.categoryId, authorId: full.authorId,
      featuredImage: full.featuredImage ?? "", status: full.status,
    } : {
      id: initial?.id ?? undefined, slug: initial?.slug ?? "", title: initial?.title ?? "",
      excerpt: initial?.excerpt ?? "", body: initial?.body ?? "",
      categoryId: initial?.categoryId ?? 0, authorId: initial?.authorId ?? 0,
      featuredImage: initial?.featuredImage ?? "", status: initial?.status ?? "draft",
    },
  });
  const img = form.watch("featuredImage");

  return (
    <form className="space-y-4" onSubmit={form.handleSubmit((v) => save.mutate({ ...v, publishedAt: v.status === "published" ? new Date() : null }))}>
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <label className="text-sm font-medium">Title</label>
          <Input {...form.register("title")} placeholder="Story headline" />
          {form.formState.errors.title && <p className="text-xs text-red-400">{form.formState.errors.title.message}</p>}
        </div>
        <div className="space-y-1.5">
          <label className="text-sm font-medium">Slug</label>
          <Input {...form.register("slug")} placeholder="story-slug" />
          {form.formState.errors.slug && <p className="text-xs text-red-400">{form.formState.errors.slug.message}</p>}
        </div>
      </div>
      <div className="space-y-1.5">
        <label className="text-sm font-medium">Excerpt</label>
        <Input {...form.register("excerpt")} placeholder="One-sentence deck" />
      </div>
      <div className="grid sm:grid-cols-3 gap-4">
        <div className="space-y-1.5">
          <label className="text-sm font-medium">Category</label>
          <Select value={form.watch("categoryId")?.toString()} onValueChange={(v) => form.setValue("categoryId", Number(v), { shouldValidate: true })}>
            <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
            <SelectContent>{meta?.categories.map((c) => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <label className="text-sm font-medium">Author</label>
          <Select value={form.watch("authorId")?.toString()} onValueChange={(v) => form.setValue("authorId", Number(v), { shouldValidate: true })}>
            <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
            <SelectContent>{meta?.authors.map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.name}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <label className="text-sm font-medium">Status</label>
          <Select value={form.watch("status")} onValueChange={(v) => form.setValue("status", v as "draft" | "published")}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="published">Published</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="space-y-1.5">
        <label className="text-sm font-medium">Featured image</label>
        <div className="grid grid-cols-7 gap-2">
          {IMAGE_OPTIONS.map((n) => (
            <button type="button" key={n} onClick={() => form.setValue("featuredImage", `/images/articles/${n}.png`)}
              className={`aspect-video rounded-md overflow-hidden border-2 transition-all ${img === `/images/articles/${n}.png` ? "border-gg-accent scale-105" : "border-transparent opacity-70 hover:opacity-100"}`}>
              <img src={`/images/articles/${n}.png`} alt={n} className="w-full h-full object-cover" loading="lazy" />
            </button>
          ))}
        </div>
        <Input {...form.register("featuredImage")} placeholder="or paste an image URL" className="mt-2" />
      </div>
      <div className="space-y-1.5">
        <label className="text-sm font-medium">Body (blank line between paragraphs, "## " for subheadings)</label>
        <Textarea rows={12} {...form.register("body")} placeholder="Write the story..." />
        {form.formState.errors.body && <p className="text-xs text-red-400">{form.formState.errors.body.message}</p>}
      </div>
      <div className="flex gap-2">
        <Button type="submit" disabled={save.isPending}>{save.isPending ? "Saving..." : "Save article"}</Button>
        <Button type="button" variant="outline" onClick={onDone}>Cancel</Button>
      </div>
    </form>
  );
}

export default function AdminPage() {
  const { user, isLoading } = useAuth({ redirectOnUnauthenticated: true });
  const isAdmin = user?.role === "admin";
  const { data: stats } = trpc.site.adminStats.useQuery(undefined, { enabled: isAdmin });
  const { data: articles, isLoading: loadingArticles } = trpc.site.adminArticles.useQuery(undefined, { enabled: isAdmin });
  const { data: subscribers } = trpc.site.adminSubscribers.useQuery(undefined, { enabled: isAdmin });
  const del = trpc.site.adminDeleteArticle.useMutation();
  const utils = trpc.useUtils();
  const [editing, setEditing] = useState<Partial<Values> | null>(null);

  if (isLoading) return <div className="mx-auto max-w-7xl px-4 py-10"><Skeleton className="h-64 rounded-xl" /></div>;

  if (!isAdmin) {
    return (
      <div className="mx-auto max-w-xl px-4 py-24 text-center">
        <h1 className="gg-h2">Admins only</h1>
        <p className="mt-3 text-sm text-[var(--gg-text-muted)]">
          This area is restricted to GGWIRE editors. Your account ({user?.name ?? "signed out"}) doesn't have the admin role.
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="gg-h1">CMS</h1>
          <p className="text-sm text-[var(--gg-text-muted)]">Welcome, {user?.name}. Manage stories, images and subscribers.</p>
        </div>
        <Button onClick={() => setEditing({})}><Plus className="w-4 h-4 mr-2" />New article</Button>
      </div>

      {stats && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {[
            { icon: FileText, label: "Articles", v: stats.articles },
            { icon: MessageSquare, label: "Comments", v: stats.comments },
            { icon: Mail, label: "Subscribers", v: stats.subscribers },
            { icon: Users, label: "Users", v: stats.users },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-[var(--gg-line)] bg-[var(--gg-surface-2)] p-5">
              <s.icon className="w-5 h-5 text-gg-accent mb-3" />
              <p className="gg-display text-3xl font-bold">{s.v}</p>
              <p className="text-xs uppercase tracking-widest text-[var(--gg-text-muted)]">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      <Tabs defaultValue="articles">
        <TabsList className="mb-6">
          <TabsTrigger value="articles">Articles</TabsTrigger>
          <TabsTrigger value="subscribers">Newsletter ({subscribers?.length ?? 0})</TabsTrigger>
        </TabsList>
        <TabsContent value="articles">
          {loadingArticles ? <Skeleton className="h-64 rounded-xl" /> : (
            <div className="rounded-xl border border-[var(--gg-line)] overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Author</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Views</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {articles?.map((a) => (
                    <TableRow key={a.id}>
                      <TableCell className="max-w-[320px]">
                        <p className="font-medium truncate">{a.title}</p>
                        <p className="text-xs text-[var(--gg-text-muted)]">{a.slug}</p>
                      </TableCell>
                      <TableCell>{a.categoryName}</TableCell>
                      <TableCell>{a.authorName}</TableCell>
                      <TableCell><Badge variant={a.status === "published" ? "default" : "secondary"}>{a.status}</Badge></TableCell>
                      <TableCell>{formatViews(a.views)}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => setEditing({ id: a.id, slug: a.slug, title: a.title, status: a.status as "draft" | "published" })}>
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => { if (confirm("Delete this article?")) del.mutate({ id: a.id }, { onSuccess: () => utils.invalidate() }); }}>
                          <Trash2 className="w-4 h-4 text-red-400" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>
        <TabsContent value="subscribers">
          <div className="rounded-xl border border-[var(--gg-line)] overflow-hidden">
            <Table>
              <TableHeader><TableRow><TableHead>Email</TableHead><TableHead>Subscribed</TableHead></TableRow></TableHeader>
              <TableBody>
                {(subscribers ?? []).map((s) => (
                  <TableRow key={s.id}><TableCell>{s.email}</TableCell><TableCell>{formatDate(s.subscribedAt)}</TableCell></TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={editing !== null} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing?.id ? "Edit article" : "New article"}</DialogTitle></DialogHeader>
          {editing && <ArticleEditor initial={editing} onDone={() => setEditing(null)} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}
