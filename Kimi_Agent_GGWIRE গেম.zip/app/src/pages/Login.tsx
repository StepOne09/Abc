import { useEffect } from "react";
import { Link, useNavigate } from "react-router";
import { Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";

export function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);
  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);
  return url.toString();
}

export default function Login() {
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const claim = trpc.auth.claimAdmin.useMutation({
    onSettled: () => utils.invalidate(),
  });

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      claim.mutate();
      navigate("/");
    }
  }, [isLoading, isAuthenticated, navigate]);

  return (
    <div className="min-h-screen grid place-items-center px-4 bg-[var(--gg-surface)] relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none opacity-30" style={{ background: "radial-gradient(600px 300px at 50% 0%, var(--gg-accent-soft), transparent)" }} />
      <Card className="w-full max-w-sm relative border-[var(--gg-line)] bg-[var(--gg-surface-2)]">
        <CardHeader className="text-center">
          <Link to="/" className="mx-auto mb-2 flex items-center gap-2">
            <span className="grid place-items-center w-9 h-9 rounded-md bg-gg-accent text-white"><Zap className="w-5 h-5" fill="currentColor" /></span>
            <span className="gg-display text-2xl font-bold">GG<span className="text-gg-accent">WIRE</span></span>
          </Link>
          <CardTitle>Welcome back</CardTitle>
          <CardDescription>Sign in to comment, bookmark and sync your reading.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button className="w-full" size="lg" onClick={() => { window.location.href = getOAuthUrl(); }}>
            Sign in with Kimi
          </Button>
          <p className="text-center text-xs text-[var(--gg-text-muted)]">
            New here? <Link to="/signup" className="text-gg-accent hover:underline">Create an account</Link> — it takes ten seconds.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
