import { useMemo, useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/providers/trpc";
import type { MatchItem } from "@/types";
import { formatDate } from "@/types";
import { Skeleton } from "@/components/ui/skeleton";

const GAMES = ["All", "Valorant", "CS2", "League of Legends", "Apex Legends"];

function MatchCard({ m }: { m: MatchItem }) {
  const live = m.status === "live";
  return (
    <div className="rounded-xl border border-[var(--gg-line)] bg-[var(--gg-surface-2)] p-5 gg-card-hover">
      <div className="flex items-center justify-between mb-4">
        <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--gg-text-muted)]">{m.game}</span>
        <span className={`text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
          live ? "bg-red-500/15 text-red-400 animate-pulse" : m.status === "finished" ? "bg-[var(--gg-surface-3)] text-[var(--gg-text-muted)]" : "bg-gg-accent-soft text-gg-accent"
        }`}>{live ? "● Live" : m.status}</span>
      </div>
      <div className="space-y-2">
        {[ [m.teamA, m.teamAScore], [m.teamB, m.teamBScore] ].map(([t, s], i) => (
          <div key={i} className="flex items-center justify-between">
            <span className="font-semibold">{t}</span>
            <span className="gg-display text-2xl font-bold text-gg-accent">{s ?? "–"}</span>
          </div>
        ))}
      </div>
      <p className="mt-4 text-xs text-[var(--gg-text-muted)]">{m.event}</p>
      <p className="text-xs text-[var(--gg-text-muted)]">{formatDate(m.startTime)}{m.notes ? ` · ${m.notes}` : ""}</p>
    </div>
  );
}

function Bracket() {
  // Demo bracket: 8 teams, quarter → semi → final
  const rounds = [
    { name: "Quarterfinals", pairs: [["Sentinels", "LOUD"], ["Fnatic", "Paper Rex"], ["DRX", "Leviatán"], ["EDG", "NRG"]] },
    { name: "Semifinals", pairs: [["Sentinels", "Paper Rex"], ["DRX", "NRG"]] },
    { name: "Grand Final", pairs: [["Sentinels", "DRX"]] },
  ];
  const winners = [["Sentinels", "Paper Rex", "DRX", "NRG"], ["Sentinels", "DRX"], ["Sentinels"]];
  return (
    <div className="overflow-x-auto pb-4">
      <div className="grid grid-cols-3 gap-8 min-w-[720px]">
        {rounds.map((r, ri) => (
          <div key={r.name} className="flex flex-col">
            <p className="text-xs font-bold uppercase tracking-widest text-[var(--gg-text-muted)] mb-4 text-center">{r.name}</p>
            <div className="flex-1 flex flex-col justify-around gap-4">
              {r.pairs.map((pair, pi) => (
                <div key={pi} className="rounded-lg border border-[var(--gg-line)] bg-[var(--gg-surface-2)] overflow-hidden">
                  {pair.map((team, ti) => {
                    const w = winners[ri][pi];
                    return (
                      <div key={team} className={`flex justify-between px-3 py-2 text-sm ${ti === 1 ? "border-t border-[var(--gg-line)]" : ""} ${team === w ? "text-gg-accent font-semibold" : "text-[var(--gg-text-muted)]"}`}>
                        <span>{team}</span>
                        {team === w && <span>✓</span>}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      <p className="mt-6 text-xs text-[var(--gg-text-muted)] text-center">Demo bracket — VCT Masters Shanghai (illustrative)</p>
    </div>
  );
}

export default function EsportsPage() {
  const { data: matches, isLoading } = trpc.site.matches.useQuery();
  const [game, setGame] = useState("All");

  const filtered = useMemo(
    () => (matches ?? []).filter((m) => game === "All" || m.game === game),
    [matches, game],
  );
  const live = filtered.filter((m) => m.status === "live");
  const upcoming = filtered.filter((m) => m.status === "upcoming");
  const finished = filtered.filter((m) => m.status === "finished");

  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
        <div>
          <h1 className="gg-h1">Esports</h1>
          <p className="mt-2 text-[var(--gg-text-muted)]">Live scores, fixtures and tournament brackets.</p>
        </div>
        <Tabs value={game} onValueChange={setGame}>
          <TabsList>
            {GAMES.map((g) => <TabsTrigger key={g} value={g}>{g}</TabsTrigger>)}
          </TabsList>
        </Tabs>
      </div>

      {isLoading ? (
        <div className="grid md:grid-cols-3 gap-4">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-44 rounded-xl" />)}</div>
      ) : (
        <Tabs defaultValue="live">
          <TabsList className="mb-6">
            <TabsTrigger value="live">Live ({live.length})</TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming ({upcoming.length})</TabsTrigger>
            <TabsTrigger value="results">Results ({finished.length})</TabsTrigger>
            <TabsTrigger value="bracket">Bracket</TabsTrigger>
          </TabsList>
          <TabsContent value="live">
            {live.length === 0 ? <p className="text-sm text-[var(--gg-text-muted)]">No live matches right now.</p> : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">{live.map((m) => <MatchCard key={m.id} m={m} />)}</div>
            )}
          </TabsContent>
          <TabsContent value="upcoming">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">{upcoming.map((m) => <MatchCard key={m.id} m={m} />)}</div>
          </TabsContent>
          <TabsContent value="results">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">{finished.map((m) => <MatchCard key={m.id} m={m} />)}</div>
          </TabsContent>
          <TabsContent value="bracket"><Bracket /></TabsContent>
        </Tabs>
      )}
    </div>
  );
}
