import { Link } from "react-router";
import { Flame, Trophy, Mail, Check } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { CardLarge, CardSmall, CardRow, CategoryTag } from "@/components/ArticleCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useState } from "react";
import type { MatchItem } from "@/types";
import { formatDate } from "@/types";

function Ticker({ items }: { items: { slug: string; title: string }[] }) {
  const doubled = [...items, ...items];
  return (
    <div className="border-y border-[var(--gg-line)] bg-[var(--gg-surface-2)] overflow-hidden">
      <div className="flex items-center">
        <span className="shrink-0 px-4 py-2 text-xs font-bold uppercase tracking-widest text-gg-accent border-r border-[var(--gg-line)] flex items-center gap-1.5">
          <Flame className="w-3.5 h-3.5" />Trending
        </span>
        <div className="overflow-hidden flex-1">
          <div className="gg-ticker-track flex whitespace-nowrap py-2">
            {doubled.map((t, i) => (
              <Link key={i} to={`/article/${t.slug}`} className="mx-6 text-sm text-[var(--gg-text-muted)] hover:text-gg-accent transition-colors">
                {t.title}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MatchCard({ m }: { m: MatchItem }) {
  return (
    <div className="rounded-xl border border-[var(--gg-line)] bg-[var(--gg-surface-2)] p-4 gg-card-hover">
      <div className="flex items-center justify-between mb-3">
        <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--gg-text-muted)]">{m.game}</span>
        <span className={`text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
          m.status === "live" ? "bg-red-500/15 text-red-400 animate-pulse" :
          m.status === "finished" ? "bg-[var(--gg-surface-3)] text-[var(--gg-text-muted)]" : "bg-gg-accent-soft text-gg-accent"
        }`}>{m.status === "live" ? "● Live" : m.status}</span>
      </div>
      <div className="space-y-1.5 font-semibold text-sm">
        <div className="flex justify-between"><span>{m.teamA}</span><span className="text-gg-accent">{m.teamAScore ?? "–"}</span></div>
        <div className="flex justify-between"><span>{m.teamB}</span><span className="text-gg-accent">{m.teamBScore ?? "–"}</span></div>
      </div>
      <p className="mt-3 text-xs text-[var(--gg-text-muted)]">{m.event} · {formatDate(m.startTime)}</p>
    </div>
  );
}

function Newsletter() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);
  const sub = trpc.site.subscribe.useMutation({ onSuccess: () => setDone(true) });
  return (
    <section className="rounded-2xl border border-gg-accent/30 bg-gradient-to-br from-gg-accent-soft to-transparent p-8 md:p-12 text-center">
      <Mail className="w-8 h-8 mx-auto text-gg-accent mb-3" />
      <h2 className="gg-h2">The Daily GG</h2>
      <p className="mt-2 text-sm text-[var(--gg-text-muted)] max-w-md mx-auto">
        One email every morning with the five stories that matter in gaming and esports. No spam, ever.
      </p>
      {done ? (
        <p className="mt-6 inline-flex items-center gap-2 text-emerald-400 font-semibold"><Check className="w-4 h-4" />You're on the list. See you tomorrow.</p>
      ) : (
        <form className="mt-6 flex flex-col sm:flex-row gap-2 max-w-md mx-auto" onSubmit={(e) => { e.preventDefault(); if (email) sub.mutate({ email }); }}>
          <Input type="email" required placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className="bg-[var(--gg-surface)]" />
          <Button type="submit" disabled={sub.isPending}>Subscribe</Button>
        </form>
      )}
    </section>
  );
}

export default function Home() {
  const { data, isLoading } = trpc.articles.home.useQuery();
  const { data: matches } = trpc.site.matches.useQuery();

  if (isLoading || !data) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 space-y-4">
        <Skeleton className="h-[420px] rounded-xl" />
        <Skeleton className="h-10 rounded-xl" />
        <div className="grid md:grid-cols-3 gap-4">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-64 rounded-xl" />)}</div>
      </div>
    );
  }

  return (
    <div>
      {/* Hero */}
      <section className="mx-auto max-w-7xl px-4 pt-8 pb-6 grid lg:grid-cols-5 gap-4">
        <div className={`lg:col-span-3 gg-category-${data.featured?.category.color ?? "news"}`}>
          {data.featured && (
            <Link to={`/article/${data.featured.slug}`} className="group relative block rounded-xl overflow-hidden border border-[var(--gg-line)] gg-card-hover gg-img-zoom h-full min-h-[380px]">
              <img src={data.featured.featuredImage ?? ""} alt="" className="absolute inset-0 w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
              <div className="absolute bottom-0 p-6">
                <CategoryTag slug={data.featured.category.slug} name={data.featured.category.name} color={data.featured.category.color} />
                <h1 className="gg-h2 mt-3 text-white max-w-2xl group-hover:text-cat transition-colors">{data.featured.title}</h1>
                <p className="mt-2 text-sm text-white/70 max-w-xl line-clamp-2">{data.featured.excerpt}</p>
              </div>
            </Link>
          )}
        </div>
        <div className="lg:col-span-2 flex flex-col gap-4">
          {data.secondary.slice(0, 3).map((a) => <CardSmall key={a.id} a={a} />)}
        </div>
      </section>

      <Ticker items={data.trending.map((t) => ({ slug: t.slug, title: t.title }))} />

      {/* Latest grid + sidebar */}
      <section className="mx-auto max-w-7xl px-4 py-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="gg-h2">Latest News</h2>
          <Link to="/category/news" className="text-sm text-gg-accent hover:underline">View all</Link>
        </div>
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            {data.latest.slice(0, 5).map((a) => <CardRow key={a.id} a={a} />)}
          </div>
          <div className="space-y-4">
            <div className="rounded-xl border border-[var(--gg-line)] bg-[var(--gg-surface-2)] p-5">
              <p className="text-xs font-bold uppercase tracking-widest text-[var(--gg-text-muted)] mb-4 flex items-center gap-1.5"><Trophy className="w-3.5 h-3.5 text-gg-accent" />Editors' Picks</p>
              <div className="space-y-3">
                {data.editorsPicks.map((a) => <CardSmall key={a.id} a={a} />)}
              </div>
            </div>
            <div className="rounded-xl border border-[var(--gg-line)] bg-[var(--gg-surface-2)] p-5">
              <p className="text-xs font-bold uppercase tracking-widest text-[var(--gg-text-muted)] mb-4">Sections</p>
              <div className="flex flex-wrap gap-2">
                {data.categories.map((c) => <CategoryTag key={c.id} slug={c.slug} name={c.name} color={c.color} />)}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Esports scores */}
      {matches && matches.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 pb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="gg-h2">Esports Scores</h2>
            <Link to="/esports" className="text-sm text-gg-accent hover:underline">Fixtures &amp; brackets</Link>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {matches.slice(0, 4).map((m) => <MatchCard key={m.id} m={m} />)}
          </div>
        </section>
      )}

      {/* Guides + Reviews */}
      <section className="mx-auto max-w-7xl px-4 pb-12">
        <div className="grid md:grid-cols-2 gap-6">
          {data.latest.filter((a) => a.category.slug === "guides" || a.category.slug === "reviews").slice(0, 2).map((a) => <CardLarge key={a.id} a={a} />)}
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 pb-4"><Newsletter /></div>
    </div>
  );
}
