import { Link } from "react-router";
import { Eye } from "lucide-react";
import type { ArticleCard as ArticleCardT } from "@/types";
import { formatDate, formatViews } from "@/types";

export function CategoryTag({ slug, name, color }: { slug: string; name: string; color: string }) {
  return (
    <Link
      to={`/category/${slug}`}
      className={`inline-block text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-cat-soft text-cat gg-category-${color} hover:opacity-80`}
    >
      {name}
    </Link>
  );
}

export function CardLarge({ a }: { a: ArticleCardT }) {
  return (
    <Link to={`/article/${a.slug}`} className={`group block rounded-xl border border-[var(--gg-line)] bg-[var(--gg-surface-2)] overflow-hidden gg-card-hover gg-img-zoom gg-category-${a.category.color}`}>
      <div className="aspect-video overflow-hidden">
        <img src={a.featuredImage ?? ""} alt={a.title} loading="lazy" className="w-full h-full object-cover" />
      </div>
      <div className="p-5">
        <CategoryTag slug={a.category.slug} name={a.category.name} color={a.category.color} />
        <h3 className="gg-h3 mt-2 group-hover:text-cat transition-colors">{a.title}</h3>
        <p className="mt-2 text-sm text-[var(--gg-text-muted)] line-clamp-2">{a.excerpt}</p>
        <Meta a={a} />
      </div>
    </Link>
  );
}

export function CardSmall({ a }: { a: ArticleCardT }) {
  return (
    <Link to={`/article/${a.slug}`} className={`group flex gap-3 rounded-xl border border-[var(--gg-line)] bg-[var(--gg-surface-2)] p-3 gg-card-hover gg-img-zoom gg-category-${a.category.color}`}>
      <div className="w-28 aspect-video rounded-lg overflow-hidden shrink-0">
        <img src={a.featuredImage ?? ""} alt="" loading="lazy" className="w-full h-full object-cover" />
      </div>
      <div className="min-w-0">
        <CategoryTag slug={a.category.slug} name={a.category.name} color={a.category.color} />
        <p className="mt-1 text-sm font-semibold leading-snug line-clamp-2 group-hover:text-cat transition-colors">{a.title}</p>
      </div>
    </Link>
  );
}

export function CardRow({ a }: { a: ArticleCardT }) {
  return (
    <Link to={`/article/${a.slug}`} className={`group grid grid-cols-[1fr_180px] sm:grid-cols-[1fr_260px] gap-4 rounded-xl border border-[var(--gg-line)] bg-[var(--gg-surface-2)] p-4 gg-card-hover gg-img-zoom gg-category-${a.category.color}`}>
      <div className="min-w-0">
        <CategoryTag slug={a.category.slug} name={a.category.name} color={a.category.color} />
        <h3 className="gg-h3 mt-2 group-hover:text-cat transition-colors">{a.title}</h3>
        <p className="mt-2 text-sm text-[var(--gg-text-muted)] line-clamp-2 hidden sm:block">{a.excerpt}</p>
        <Meta a={a} />
      </div>
      <div className="aspect-video rounded-lg overflow-hidden">
        <img src={a.featuredImage ?? ""} alt="" loading="lazy" className="w-full h-full object-cover" />
      </div>
    </Link>
  );
}

function Meta({ a }: { a: ArticleCardT }) {
  return (
    <div className="mt-3 flex items-center gap-3 text-xs text-[var(--gg-text-muted)]">
      <span>{a.author.name}</span>
      <span>·</span>
      <span>{formatDate(a.publishedAt)}</span>
      <span className="inline-flex items-center gap-1 ml-auto"><Eye className="w-3.5 h-3.5" />{formatViews(a.views)}</span>
    </div>
  );
}
