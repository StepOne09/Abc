import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router";
import { Search, Moon, Sun, Menu, X, Bookmark, Shield, LogOut, User, Zap } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";

const NAV = [
  { slug: "news", label: "News" },
  { slug: "esports", label: "Esports" },
  { slug: "guides", label: "Guides" },
  { slug: "reviews", label: "Reviews" },
  { slug: "entertainment", label: "Entertainment" },
  { slug: "tech", label: "Tech" },
  { slug: "opinions", label: "Opinions" },
];

export function useTheme() {
  const [theme, setTheme] = useState<"dark" | "light">(() =>
    document.documentElement.classList.contains("light") ? "light" : "dark",
  );
  const toggle = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    document.documentElement.classList.toggle("light", next === "light");
    localStorage.setItem("gg-theme", next);
  };
  return { theme, toggle };
}

export function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2 shrink-0">
      <span className="grid place-items-center w-8 h-8 rounded-md bg-gg-accent text-white">
        <Zap className="w-4 h-4" fill="currentColor" />
      </span>
      <span className="gg-display text-xl font-bold tracking-tight">
        GG<span className="text-gg-accent">WIRE</span>
      </span>
    </Link>
  );
}

function MegaMenu({ slug, label }: { slug: string; label: string }) {
  const { data } = trpc.articles.byCategory.useQuery({ slug, sort: "latest", limit: 1 }, { staleTime: 5 * 60 * 1000 });
  const top = data?.items?.[0];
  return (
    <div className="absolute left-0 top-full pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
      <div className="w-[560px] rounded-xl border bg-[var(--gg-surface-2)] shadow-2xl shadow-black/40 overflow-hidden flex">
        <div className="w-44 p-4 border-r border-[var(--gg-line)]">
          <p className={`text-xs font-semibold uppercase tracking-wider mb-3 text-cat gg-category-${slug}`}>{label}</p>
          <div className="flex flex-col gap-1 text-sm">
            <Link to={`/category/${slug}`} className="px-2 py-1.5 rounded-md hover:bg-[var(--gg-surface-3)]">Latest</Link>
            <Link to={`/category/${slug}?sort=popular`} className="px-2 py-1.5 rounded-md hover:bg-[var(--gg-surface-3)]">Popular</Link>
            <Link to="/esports" className="px-2 py-1.5 rounded-md hover:bg-[var(--gg-surface-3)]">Scores</Link>
          </div>
        </div>
        {top && (
          <Link to={`/article/${top.slug}`} className="flex-1 p-4 flex gap-3 gg-card-hover">
            <div className="w-36 aspect-video rounded-lg overflow-hidden gg-img-zoom shrink-0">
              <img src={top.featuredImage ?? ""} alt="" className="w-full h-full object-cover" loading="lazy" />
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-wider text-[var(--gg-text-muted)] mb-1">Top story</p>
              <p className="text-sm font-semibold leading-snug">{top.title}</p>
            </div>
          </Link>
        )}
      </div>
    </div>
  );
}

function Header() {
  const { theme, toggle } = useTheme();
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <header className={`sticky top-0 z-40 border-b border-[var(--gg-line)] bg-[var(--gg-surface)]/90 backdrop-blur transition-all ${scrolled ? "shadow-lg shadow-black/20" : ""}`}>
      <div className="mx-auto max-w-7xl px-4 h-16 flex items-center gap-6">
        <Logo />
        <nav className="hidden lg:flex items-center gap-1 h-full">
          {NAV.map((n) => (
            <div key={n.slug} className="relative h-full flex items-center group">
              <NavLink
                to={`/category/${n.slug}`}
                className={({ isActive }) =>
                  `px-3 py-2 text-sm font-medium rounded-md transition-colors hover:text-cat gg-category-${n.slug} ${isActive ? "text-cat" : "text-[var(--gg-text-muted)]"}`
                }
              >
                {n.label}
              </NavLink>
              <MegaMenu slug={n.slug} label={n.label} />
            </div>
          ))}
          <NavLink to="/esports" className="px-3 py-2 text-sm font-medium text-[var(--gg-text-muted)] hover:text-gg-accent rounded-md">Scores</NavLink>
        </nav>
        <div className="ml-auto flex items-center gap-1.5">
          <Button variant="ghost" size="icon" onClick={() => navigate("/search")} aria-label="Search">
            <Search className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={toggle} aria-label="Toggle theme">
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>
          {isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Account"><User className="w-4 h-4" /></Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <div className="px-3 py-2 text-xs text-[var(--gg-text-muted)] truncate">{user?.name}</div>
                <DropdownMenuItem onClick={() => navigate("/bookmarks")}><Bookmark className="w-4 h-4 mr-2" />Bookmarks</DropdownMenuItem>
                {user?.role === "admin" && (
                  <DropdownMenuItem onClick={() => navigate("/admin")}><Shield className="w-4 h-4 mr-2" />Admin CMS</DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={logout}><LogOut className="w-4 h-4 mr-2" />Sign out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button size="sm" onClick={() => navigate("/login")}>Sign in</Button>
          )}
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Menu">
            {mobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </Button>
        </div>
      </div>
      {mobileOpen && (
        <nav className="lg:hidden border-t border-[var(--gg-line)] px-4 py-3 flex flex-col gap-1 bg-[var(--gg-surface-2)]">
          {NAV.map((n) => (
            <Link key={n.slug} to={`/category/${n.slug}`} onClick={() => setMobileOpen(false)} className="px-2 py-2 rounded-md text-sm hover:bg-[var(--gg-surface-3)]">
              {n.label}
            </Link>
          ))}
          <Link to="/esports" onClick={() => setMobileOpen(false)} className="px-2 py-2 rounded-md text-sm hover:bg-[var(--gg-surface-3)]">Scores</Link>
        </nav>
      )}
    </header>
  );
}

function Footer() {
  return (
    <footer className="border-t border-[var(--gg-line)] mt-20 bg-[var(--gg-surface-2)]">
      <div className="mx-auto max-w-7xl px-4 py-12 grid gap-10 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo />
          <p className="mt-4 text-sm text-[var(--gg-text-muted)] max-w-sm">
            GGWIRE is gaming news, esports and entertainment — reported with energy, verified with data.
          </p>
        </div>
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[var(--gg-text-muted)] mb-3">Sections</p>
          <div className="grid grid-cols-2 gap-2 text-sm">
            {NAV.map((n) => <Link key={n.slug} to={`/category/${n.slug}`} className="hover:text-gg-accent">{n.label}</Link>)}
          </div>
        </div>
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[var(--gg-text-muted)] mb-3">Company</p>
          <div className="flex flex-col gap-2 text-sm">
            <Link to="/about" className="hover:text-gg-accent">About</Link>
            <Link to="/contact" className="hover:text-gg-accent">Contact</Link>
            <Link to="/esports" className="hover:text-gg-accent">Esports Scores</Link>
          </div>
        </div>
      </div>
      <div className="border-t border-[var(--gg-line)] py-4 text-center text-xs text-[var(--gg-text-muted)]">
        © 2026 GGWIRE — Gaming News, Esports &amp; Entertainment
      </div>
    </footer>
  );
}

export function SiteLayout() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
